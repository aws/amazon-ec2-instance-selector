---
name: Feature Request
about: Suggest a feature to the EKS AMI

---
<!-- Please only use this template for feature requests -->

**What would you like to be added**:

**Why is this needed**:

<!-- If this is a security issue, please do not discuss on GitHub. Please report any suspected or confirmed security issues to AWS Security https://aws.amazon.com/security/vulnerability-reporting/ -->
